# ScrollVerse Bible Android project

This version includes a complete offline English–Telugu Bible reader using the supplied USFM sources.

## Included translations
- English: World English Bible (WEB), public domain. Source: https://ebible.org/engwebp/
- Telugu: Biblica® Open Telugu Contemporary Version, CC BY-SA 4.0. Source: https://ebible.org/Scriptures/details.php?id=telotsa

See `BIBLE_TEXT_LICENSES.txt` for attribution and license notes.

## Features
- 66-book navigation in English and Telugu
- Chapter selector
- Verse-by-verse reader with English, Telugu, or both
- Search across the Bible
- Local bookmarks and highlights
- Offline reading after installation

## Build
The GitHub Actions workflow should extract this project ZIP and run `:app:assembleDebug` using Java 17 and Android SDK 35.

## Important
The text is bundled locally in `app/src/main/assets/bible.json`. The data was parsed from the USFM source archives supplied for this project. Verse numbering can differ between translations, so a small number of verse entries may be present in one language only. Please verify the final app on a device before distributing it.
