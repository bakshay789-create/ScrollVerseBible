# ScrollVerse Bible — Android starter project

An original Kotlin + Jetpack Compose starter for a bilingual Telugu/English scrolling Bible app.

## Included in this starter
- Verse-by-verse scrolling UI
- English / Telugu / bilingual display switch
- Search over the included sample verses
- Bookmarks persisted locally with Preferences DataStore
- Highlights persisted locally with Preferences DataStore
- Short study explanations for sample passages
- Dark, forest-green and gold visual theme

## Important limitations in version 0.1
- The app currently contains only four sample passages, not a complete Bible.
- Telugu text is a draft sample and is not represented as an official published translation.
- Audio playback and scheduled daily notifications are not implemented yet; the UI points to these next milestones.
- The search is local and only searches the sample passages.
- Bookmarks and highlights are local to this app installation.

## Build in Android Studio
1. Install Android Studio with a compatible JDK (JDK 17 recommended).
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Run the `app` configuration on an emulator or Android phone with USB debugging enabled.
5. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Before Play Store release
1. Choose a Telugu translation whose license explicitly allows the intended in-app distribution, or commission an original translation and secure written rights.
2. Confirm the English Bible text license for your chosen edition. KJV is public domain in many jurisdictions, but regional publishing rules can vary.
3. Add the complete licensed Bible data, book/chapter navigation, robust full-text indexing, and attribution/license notices.
4. Implement audio with licensed recordings or an appropriate text-to-speech provider.
5. Implement daily notifications using Android notification channels and WorkManager or AlarmManager as appropriate, including permission handling.
6. Add automated tests, accessibility checks, privacy disclosures, and Play Store assets.
7. Test Telugu rendering across devices and Android versions.

## Branding
App name: ScrollVerse Bible
Package: `com.scrollverse.bible`
Version: `0.1.0`
