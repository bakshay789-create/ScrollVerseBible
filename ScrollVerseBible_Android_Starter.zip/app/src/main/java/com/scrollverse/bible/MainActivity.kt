package com.scrollverse.bible

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

private val ComponentActivity.dataStore by preferencesDataStore(name = "scrollverse_preferences")
private val savedKey = stringSetPreferencesKey("saved_verses")
private val highlightedKey = stringSetPreferencesKey("highlighted_verses")

data class Verse(
    val id: String, val reference: String, val english: String, val telugu: String, val explanation: String
)

private val sampleVerses = listOf(
    Verse("psalm23-1", "Psalm 23:1",
        "The LORD is my shepherd; I shall not want.",
        "యెహోవా నా కాపరి; నాకు లేమి కలుగదు.",
        "David pictures God as a caring shepherd who guides, protects and provides."),
    Verse("psalm23-2", "Psalm 23:2",
        "He maketh me to lie down in green pastures: he leadeth me beside the still waters.",
        "పచ్చికగల చోట్ల ఆయన నన్ను పరుండజేయుచున్నాడు; శాంతికరమైన నీళ్లయొద్ద నన్ను నడిపించుచున్నాడు.",
        "Green pastures and quiet waters picture rest, peace and refreshment in God's care."),
    Verse("john3-16", "John 3:16",
        "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.",
        "దేవుడు లోకమును ఎంతో ప్రేమించెను. ఆయన తన అద్వితీయ కుమారుని అనుగ్రహించెను; ఆయనయందు విశ్వాసముంచువాడు నశింపక నిత్యజీవము పొందును.",
        "This verse expresses God's love and the Christian promise of eternal life through faith in Jesus."),
    Verse("phil4-6", "Philippians 4:6",
        "Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God.",
        "దేనినిగూర్చియు చింతపడకుడి; ప్రతి విషయములోను ప్రార్థన విజ్ఞాపనల ద్వారా కృతజ్ఞతతో మీ విన్నపములను దేవునికి తెలియజేయుడి.",
        "Paul encourages believers to bring their worries to God through prayer and gratitude.")
)

private val forest = Color(0xFF19251C)
private val cardGreen = Color(0xFF243128)
private val gold = Color(0xFFC8A96B)
private val parchment = Color(0xFFF5EAD2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedFlow = dataStore.data.map { it[savedKey] ?: emptySet() }
        val highlightedFlow = dataStore.data.map { it[highlightedKey] ?: emptySet() }
        setContent {
            val scope = rememberCoroutineScope()
            val saved by savedFlow.collectAsState(initial = emptySet())
            val highlighted by highlightedFlow.collectAsState(initial = emptySet())
            var language by remember { mutableStateOf("Both") }
            var query by remember { mutableStateOf("") }
            var selectedTab by remember { mutableStateOf("Read") }
            var selectedVerse by remember { mutableStateOf(sampleVerses.first().id) }
            var showExplanation by remember { mutableStateOf(false) }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = gold, background = forest, surface = cardGreen,
                onPrimary = forest, onBackground = parchment, onSurface = parchment
            )) {
                Scaffold(containerColor = forest) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding)) {
                        Column(Modifier.fillMaxWidth().background(forest).padding(18.dp)) {
                            Text("📖  ScrollVerse", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = parchment)
                            Text("READ  ·  REFLECT  ·  GROW", fontSize = 11.sp, color = gold)
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Read", "Saved", "Study").forEach { tab ->
                                    FilterChip(
                                        selected = selectedTab == tab, onClick = { selectedTab = tab },
                                        label = { Text(tab) }
                                    )
                                }
                            }
                        }

                        if (selectedTab == "Read") {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("English", "తెలుగు", "Both").forEach { lang ->
                                    FilterChip(selected = language == lang, onClick = { language = lang }, label = { Text(lang) })
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp).background(cardGreen, RoundedCornerShape(12.dp)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = gold)
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(value = query, onValueChange = { query = it },
                                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                                    decorationBox = { inner -> if (query.isEmpty()) Text("Search verse or reference…", color = Color.LightGray); inner() })
                            }
                        }

                        val filtered = sampleVerses.filter { verse ->
                            (selectedTab != "Saved" || verse.id in saved || verse.id in highlighted) &&
                            (selectedTab != "Study" || verse.id == selectedVerse) &&
                            (query.isBlank() || verse.reference.contains(query, true) ||
                                verse.english.contains(query, true) || verse.telugu.contains(query, true))
                        }

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (selectedTab == "Study") {
                                item {
                                    Text("Verse study", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = parchment)
                                    Text("Select a passage to reflect on its meaning.", color = Color.LightGray)
                                }
                            }
                            items(filtered, key = { it.id }) { verse ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = if (verse.id in highlighted) Color(0xFF3B402C) else cardGreen),
                                    shape = RoundedCornerShape(18.dp)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                        Text(verse.reference, color = gold, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.height(10.dp))
                                        if (language != "తెలుగు") Text(verse.english, fontSize = 18.sp, lineHeight = 27.sp, color = parchment)
                                        if (language != "English") {
                                            if (language == "Both") Spacer(Modifier.height(10.dp))
                                            Text(verse.telugu, fontSize = 18.sp, lineHeight = 29.sp, color = parchment)
                                        }
                                        if (selectedTab == "Study" || showExplanation && selectedVerse == verse.id) {
                                            Spacer(Modifier.height(12.dp))
                                            HorizontalDivider(color = Color(0xFF485348))
                                            Spacer(Modifier.height(10.dp))
                                            Text("Study note", color = gold, fontWeight = FontWeight.Bold)
                                            Text(verse.explanation, color = parchment, lineHeight = 22.sp)
                                        }
                                        Spacer(Modifier.height(14.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = {
                                                scope.launch { dataStore.edit { prefs ->
                                                    val current = (prefs[savedKey] ?: emptySet()).toMutableSet()
                                                    if (!current.add(verse.id)) current.remove(verse.id)
                                                    prefs[savedKey] = current
                                                } }
                                            }) {
                                                Icon(if (verse.id in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                    contentDescription = "Bookmark verse", tint = gold)
                                            }
                                            IconButton(onClick = {
                                                scope.launch { dataStore.edit { prefs ->
                                                    val current = (prefs[highlightedKey] ?: emptySet()).toMutableSet()
                                                    if (!current.add(verse.id)) current.remove(verse.id)
                                                    prefs[highlightedKey] = current
                                                } }
                                            }) {
                                                Icon(Icons.Default.Highlight, contentDescription = "Highlight verse",
                                                    tint = if (verse.id in highlighted) gold else Color.LightGray)
                                            }
                                            TextButton(onClick = {
                                                selectedVerse = verse.id
                                                selectedTab = "Study"
                                                showExplanation = true
                                            }) { Icon(Icons.Default.Lightbulb, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Study") }
                                        }
                                    }
                                }
                            }
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = cardGreen)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Headphones, contentDescription = null, tint = gold)
                                            Spacer(Modifier.width(8.dp))
                                            Column {
                                                Text("Audio Bible", color = parchment, fontWeight = FontWeight.SemiBold)
                                                Text("Audio engine will be connected in the next milestone.", color = Color.LightGray, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                                Text("Prototype content only. Confirm Telugu translation rights and license before publishing.", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
