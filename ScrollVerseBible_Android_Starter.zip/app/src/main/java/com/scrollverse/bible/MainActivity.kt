package com.scrollverse.bible

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "scrollverse_preferences")
private val savedKey = stringSetPreferencesKey("saved_verses")
private val highlightedKey = stringSetPreferencesKey("highlighted_verses")

data class BibleBook(val code: String, val english: String, val telugu: String, val chapters: List<Int>)
data class BibleVerse(val id: String, val bookCode: String, val chapter: Int, val verse: Int, val english: String, val telugu: String) {
    fun reference(book: BibleBook, language: String): String {
        val name = if (language == "తెలుగు") book.telugu else book.english
        return "$name $chapter:$verse"
    }
}
data class BibleData(val books: List<BibleBook>, val verses: List<BibleVerse>)

private fun loadBible(activity: ComponentActivity): BibleData {
    val raw = activity.assets.open("bible.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val root = JSONObject(raw)
    val bookArray = root.getJSONArray("books")
    val books = buildList {
        for (i in 0 until bookArray.length()) {
            val item = bookArray.getJSONObject(i)
            val chaptersJson = item.getJSONArray("chapters")
            add(BibleBook(
                code = item.getString("code"),
                english = item.getString("english"),
                telugu = item.getString("telugu"),
                chapters = (0 until chaptersJson.length()).map { chaptersJson.getInt(it) }
            ))
        }
    }
    val verseArray = root.getJSONArray("verses")
    val verses = buildList {
        for (i in 0 until verseArray.length()) {
            val item = verseArray.getJSONObject(i)
            add(BibleVerse(
                id = item.getString("id"),
                bookCode = item.getString("b"),
                chapter = item.getInt("c"),
                verse = item.getInt("v"),
                english = item.optString("en", ""),
                telugu = item.optString("te", "")
            ))
        }
    }
    return BibleData(books, verses)
}

private val forest = Color(0xFF19251C)
private val cardGreen = Color(0xFF243128)
private val gold = Color(0xFFC8A96B)
private val parchment = Color(0xFFF5EAD2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedFlow = dataStore.data.map { it[savedKey] ?: emptySet() }
        val highlightedFlow = dataStore.data.map { it[highlightedKey] ?: emptySet() }
        setContent {
            val scope = rememberCoroutineScope()
            val saved by savedFlow.collectAsState(initial = emptySet())
            val highlighted by highlightedFlow.collectAsState(initial = emptySet())
            var bible by remember { mutableStateOf<BibleData?>(null) }
            var loadError by remember { mutableStateOf<String?>(null) }
            var language by remember { mutableStateOf("Both") }
            var query by remember { mutableStateOf("") }
            var selectedTab by remember { mutableStateOf("Read") }
            var selectedBookCode by remember { mutableStateOf("GEN") }
            var selectedChapter by remember { mutableIntStateOf(1) }

            LaunchedEffect(Unit) {
                try {
                    bible = withContext(Dispatchers.IO) { loadBible(this@MainActivity) }
                } catch (e: Exception) {
                    loadError = e.message ?: "Unable to load Bible text."
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = gold, background = forest, surface = cardGreen,
                onPrimary = forest, onBackground = parchment, onSurface = parchment
            )) {
                Scaffold(containerColor = forest) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding)) {
                        Column(Modifier.fillMaxWidth().background(forest).padding(16.dp)) {
                            Text("📖 ScrollVerse Bible", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = parchment)
                            Text("COMPLETE ENGLISH & TELUGU BIBLE", fontSize = 11.sp, color = gold)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Read", "Saved", "About").forEach { tab ->
                                    FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
                                }
                            }
                        }

                        if (selectedTab != "About") {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("English", "తెలుగు", "Both").forEach { lang ->
                                    FilterChip(selected = language == lang, onClick = { language = lang }, label = { Text(lang) })
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                val books = bible?.books.orEmpty()
                                val selectedBook = books.firstOrNull { it.code == selectedBookCode }
                                BookPicker(
                                    modifier = Modifier.weight(1f),
                                    books = books,
                                    selected = selectedBook,
                                    language = language,
                                    onSelect = { book -> selectedBookCode = book.code; selectedChapter = 1 }
                                )
                                ChapterPicker(
                                    chapters = selectedBook?.chapters.orEmpty(),
                                    selectedChapter = selectedChapter,
                                    onSelect = { selectedChapter = it }
                                )
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                                    .background(cardGreen, RoundedCornerShape(12.dp)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = gold)
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(
                                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                                    singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = parchment, fontSize = 16.sp),
                                    decorationBox = { inner ->
                                        if (query.isEmpty()) Text("Search the complete Bible…", color = Color.LightGray)
                                        inner()
                                    }
                                )
                            }
                        }

                        if (selectedTab == "About") {
                            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
                                item {
                                    Text("About ScrollVerse Bible", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = gold)
                                    Spacer(Modifier.height(12.dp))
                                    Text("This app includes Bible text for offline reading in English and Telugu.", color = parchment, lineHeight = 24.sp)
                                    Spacer(Modifier.height(18.dp))
                                    Text("English text", fontWeight = FontWeight.Bold, color = gold)
                                    Text("World English Bible (WEB). Public domain. Source: ebible.org/engwebp/", color = parchment, lineHeight = 22.sp)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Telugu text", fontWeight = FontWeight.Bold, color = gold)
                                    Text("Biblica® Open Telugu Contemporary Version. Used under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0). Source: ebible.org/Scriptures/details.php?id=telotsa. The translation name and attribution are retained here. See the source page for full notices and license terms.", color = parchment, lineHeight = 22.sp)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Bible text is provided for reading. Some verse numbering can differ between translations.", color = Color.LightGray, lineHeight = 22.sp)
                                }
                            }
                        } else {
                            val currentBible = bible
                            if (currentBible == null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    if (loadError == null) CircularProgressIndicator(color = gold)
                                    else Text("Could not load Bible: $loadError", color = parchment)
                                }
                            } else {
                                val selectedBook = currentBible.books.firstOrNull { it.code == selectedBookCode } ?: currentBible.books.first()
                                val filtered = remember(currentBible, selectedBookCode, selectedChapter, query, selectedTab, saved, highlighted) {
                                    currentBible.verses.filter { verse ->
                                        val inSaved = verse.id in saved || verse.id in highlighted
                                        val matchesLocation = if (query.isNotBlank() || selectedTab == "Saved") {
                                            true
                                        } else {
                                            verse.bookCode == selectedBookCode && verse.chapter == selectedChapter
                                        }
                                        val matchesQuery = query.isBlank() ||
                                            verse.english.contains(query, ignoreCase = true) ||
                                            verse.telugu.contains(query, ignoreCase = true) ||
                                            verse.id.contains(query, ignoreCase = true) ||
                                            currentBible.books.firstOrNull { it.code == verse.bookCode }?.let {
                                                it.english.contains(query, true) || it.telugu.contains(query, true)
                                            } == true
                                        (selectedTab != "Saved" || inSaved) && matchesLocation && matchesQuery
                                    }
                                }
                                if (query.isNotBlank()) {
                                    Text("Search results: ${filtered.size}", color = gold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                                } else if (selectedTab == "Read") {
                                    Text(
                                        "${if (language == "తెలుగు") selectedBook.telugu else selectedBook.english} · Chapter $selectedChapter",
                                        color = gold, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                                    )
                                }
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 24.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (filtered.isEmpty()) {
                                        item { Text("No verses found. Try another search or choose a different chapter.", color = Color.LightGray, modifier = Modifier.padding(16.dp)) }
                                    }
                                    items(filtered, key = { it.id }) { verse ->
                                        val book = currentBible.books.firstOrNull { it.code == verse.bookCode } ?: selectedBook
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = if (verse.id in highlighted) Color(0xFF3B402C) else cardGreen),
                                            shape = RoundedCornerShape(14.dp)
                                        ) {
                                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                                Text(verse.reference(book, language), color = gold, fontWeight = FontWeight.SemiBold)
                                                Spacer(Modifier.height(8.dp))
                                                if (language != "తెలుగు" && verse.english.isNotBlank()) {
                                                    Text(verse.english, fontSize = 17.sp, lineHeight = 25.sp, color = parchment)
                                                }
                                                if (language != "English" && verse.telugu.isNotBlank()) {
                                                    if (language == "Both" && verse.english.isNotBlank()) Spacer(Modifier.height(9.dp))
                                                    Text(verse.telugu, fontSize = 18.sp, lineHeight = 29.sp, color = parchment)
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = {
                                                        scope.launch { dataStore.edit { prefs ->
                                                            val current = (prefs[savedKey] ?: emptySet()).toMutableSet()
                                                            if (!current.add(verse.id)) current.remove(verse.id)
                                                            prefs[savedKey] = current
                                                        } }
                                                    }) {
                                                        Icon(if (verse.id in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                            contentDescription = "Bookmark verse", tint = gold)
                                                    }
                                                    IconButton(onClick = {
                                                        scope.launch { dataStore.edit { prefs ->
                                                            val current = (prefs[highlightedKey] ?: emptySet()).toMutableSet()
                                                            if (!current.add(verse.id)) current.remove(verse.id)
                                                            prefs[highlightedKey] = current
                                                        } }
                                                    }) {
                                                        Icon(Icons.Default.Highlight, contentDescription = "Highlight verse",
                                                            tint = if (verse.id in highlighted) gold else Color.LightGray)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BookPicker(
    modifier: Modifier = Modifier,
    books: List<BibleBook>,
    selected: BibleBook?,
    language: String,
    onSelect: (BibleBook) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.let { if (language == "తెలుగు") it.telugu else it.english } ?: "Book", maxLines = 1)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
            books.forEach { book ->
                DropdownMenuItem(
                    text = { Text(if (language == "తెలుగు") book.telugu else book.english) },
                    onClick = { onSelect(book); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun ChapterPicker(chapters: List<Int>, selectedChapter: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text("Ch. $selectedChapter") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
            chapters.forEach { chapter ->
                DropdownMenuItem(text = { Text(chapter.toString()) }, onClick = { onSelect(chapter); expanded = false })
            }
        }
    }
}
