package com.scrollverse.bible

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.intSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "scrollverse_preferences")
private val savedKey = stringSetPreferencesKey("saved_verses")
private val highlightedKey = stringSetPreferencesKey("highlighted_verses")
private val themeKey = stringPreferencesKey("app_theme")
private val completedStudyDaysKey = intSetPreferencesKey("completed_study_days")

data class BibleBook(val code: String, val english: String, val telugu: String, val chapters: List<Int>)
data class BibleVerse(val id: String, val bookCode: String, val chapter: Int, val verse: Int, val verseLabel: String, val english: String, val telugu: String) {
    fun reference(book: BibleBook, language: String): String {
        val name = if (language == "తెలుగు") book.telugu else book.english
        return "$name $chapter:$verseLabel"
    }
}
data class BibleData(val books: List<BibleBook>, val verses: List<BibleVerse>)

private fun loadBible(activity: ComponentActivity): BibleData {
    val raw = activity.assets.open("bible.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val root = JSONObject(raw)
    val bookArray = root.getJSONArray("books")
    val books = buildList {
        for (i in 0 until bookArray.length()) {
            val item = bookArray.getJSONObject(i)
            val chaptersJson = item.getJSONArray("chapters")
            add(BibleBook(
                code = item.getString("code"),
                english = item.getString("english"),
                telugu = item.getString("telugu"),
                chapters = (0 until chaptersJson.length()).map { chaptersJson.getInt(it) }
            ))
        }
    }
    val verseArray = root.getJSONArray("verses")
    val verses = buildList {
        for (i in 0 until verseArray.length()) {
            val item = verseArray.getJSONObject(i)
            add(BibleVerse(
                id = item.getString("id"),
                bookCode = item.getString("b"),
                chapter = item.getInt("c"),
                verse = item.getInt("v"),
                verseLabel = item.optString("vLabel", item.getInt("v").toString()),
                english = item.optString("en", ""),
                telugu = item.optString("te", "")
            ))
        }
    }
    return BibleData(books, verses)
}

private data class AppPalette(
    val id: String, val label: String, val background: Color, val surface: Color,
    val accent: Color, val text: Color, val highlighted: Color, val dark: Boolean
)

private val appPalettes = listOf(
    AppPalette("forest", "Forest Green", Color(0xFF19251C), Color(0xFF243128), Color(0xFFC8A96B), Color(0xFFF5EAD2), Color(0xFF3B402C), true),
    AppPalette("light", "Clean Light", Color(0xFFF7F8FA), Color(0xFFFFFFFF), Color(0xFF315E9E), Color(0xFF20242B), Color(0xFFDCE8FA), false),
    AppPalette("sepia", "Warm Sepia", Color(0xFFF3E7D0), Color(0xFFFFF7E8), Color(0xFF815A2B), Color(0xFF3E3022), Color(0xFFEAD8B5), false),
    AppPalette("ocean", "Ocean Blue", Color(0xFF101D32), Color(0xFF1A2D49), Color(0xFF75C9F2), Color(0xFFE8F3FF), Color(0xFF29466A), true),
    AppPalette("rose", "Rose Pink", Color(0xFF2D1C27), Color(0xFF422A39), Color(0xFFFFA9C8), Color(0xFFFFEFF5), Color(0xFF63364F), true),
    AppPalette("midnight", "Midnight Black", Color(0xFF101010), Color(0xFF202020), Color(0xFFB8D7A3), Color(0xFFF2F2F2), Color(0xFF354332), true)
)
private fun paletteFor(id: String): AppPalette = appPalettes.firstOrNull { it.id == id } ?: appPalettes.first()

private data class DayReading(val day: Int, val label: String, val firstChapter: Pair<String, Int>)

// Distributes all canonical Bible chapters across 365 days without skipping a book or chapter.
private fun makeYearReadingPlan(books: List<BibleBook>): List<DayReading> {
    val chapters = books.flatMap { book -> book.chapters.map { chapter -> Triple(book, chapter, "${book.english} $chapter") } }
    if (chapters.isEmpty()) return emptyList()
    val result = mutableListOf<DayReading>()
    var index = 0
    for (day in 1..365) {
        val remaining = chapters.size - index
        val daysLeft = 366 - day
        val count = if (remaining <= 0) 0 else kotlin.math.ceil(remaining.toDouble() / daysLeft.toDouble()).toInt().coerceAtLeast(1)
        val portion = chapters.subList(index, (index + count).coerceAtMost(chapters.size))
        if (portion.isNotEmpty()) {
            val label = if (portion.size == 1) portion.first().third else "${portion.first().third}–${portion.last().third}"
            result.add(DayReading(day, label, portion.first().let { it.first.code to it.second }))
            index += portion.size
        } else {
            result.add(DayReading(day, "Catch up / reflect", chapters.last().let { it.first.code to it.second }))
        }
    }
    return result
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val savedFlow = dataStore.data.map { it[savedKey] ?: emptySet() }
        val highlightedFlow = dataStore.data.map { it[highlightedKey] ?: emptySet() }
        val themeFlow = dataStore.data.map { it[themeKey] ?: "forest" }
        val completedDaysFlow = dataStore.data.map { it[completedStudyDaysKey] ?: emptySet() }
        setContent {
            val scope = rememberCoroutineScope()
            val saved by savedFlow.collectAsState(initial = emptySet())
            val highlighted by highlightedFlow.collectAsState(initial = emptySet())
            val themeId by themeFlow.collectAsState(initial = "forest")
            val completedStudyDays by completedDaysFlow.collectAsState(initial = emptySet())
            val palette = paletteFor(themeId)
            var bible by remember { mutableStateOf<BibleData?>(null) }
            var loadError by remember { mutableStateOf<String?>(null) }
            var language by remember { mutableStateOf("Both") }
            var query by remember { mutableStateOf("") }
            var selectedTab by remember { mutableStateOf("Read") }
            var selectedBookCode by remember { mutableStateOf("GEN") }
            var selectedChapter by remember { mutableIntStateOf(1) }

            LaunchedEffect(Unit) {
                try {
                    bible = withContext(Dispatchers.IO) { loadBible(this@MainActivity) }
                } catch (e: Exception) {
                    loadError = e.message ?: "Unable to load Bible text."
                }
            }

            val scheme = if (palette.dark) darkColorScheme(
                primary = palette.accent, background = palette.background, surface = palette.surface,
                onPrimary = palette.background, onBackground = palette.text, onSurface = palette.text
            ) else lightColorScheme(
                primary = palette.accent, background = palette.background, surface = palette.surface,
                onPrimary = Color.White, onBackground = palette.text, onSurface = palette.text
            )
            MaterialTheme(colorScheme = scheme) {
                Scaffold(containerColor = palette.background) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding)) {
                        Column(Modifier.fillMaxWidth().background(palette.background).padding(16.dp)) {
                            Text("📖 ScrollVerse Bible", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = palette.text)
                            Text("COMPLETE ENGLISH & TELUGU BIBLE", fontSize = 11.sp, color = palette.accent)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Read", "Study", "Saved", "Theme", "About").forEach { tab ->
                                    FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
                                }
                            }
                        }

                        if (selectedTab == "Read" || selectedTab == "Saved") {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("English", "తెలుగు", "Both").forEach { lang ->
                                    FilterChip(selected = language == lang, onClick = { language = lang }, label = { Text(lang) })
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                val books = bible?.books.orEmpty()
                                val selectedBook = books.firstOrNull { it.code == selectedBookCode }
                                BookPicker(
                                    modifier = Modifier.weight(1f),
                                    books = books,
                                    selected = selectedBook,
                                    language = language,
                                    onSelect = { book -> selectedBookCode = book.code; selectedChapter = 1 }
                                )
                                ChapterPicker(
                                    chapters = selectedBook?.chapters.orEmpty(),
                                    selectedChapter = selectedChapter,
                                    onSelect = { selectedChapter = it }
                                )
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                                    .background(palette.surface, RoundedCornerShape(12.dp)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = palette.accent)
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(
                                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                                    singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = palette.text, fontSize = 16.sp),
                                    decorationBox = { inner ->
                                        if (query.isEmpty()) Text("Search the complete Bible…", color = palette.text.copy(alpha = 0.65f))
                                        inner()
                                    }
                                )
                            }
                        }

                        if (selectedTab == "Study") {
                            val currentBible = bible
                            if (currentBible == null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    if (loadError == null) CircularProgressIndicator(color = palette.accent)
                                    else Text("Could not load Bible: $loadError", color = palette.text)
                                }
                            } else {
                                val plan = remember(currentBible) { makeYearReadingPlan(currentBible.books) }
                                val todayDay = java.time.LocalDate.now().dayOfYear.coerceIn(1, 365)
                                val todayPlan = plan.getOrElse(todayDay - 1) { plan.last() }
                                val completedCount = completedStudyDays.count { it in 1..365 }
                                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    item {
                                        Text("📚 Daily Bible Study", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = palette.accent)
                                        Spacer(Modifier.height(6.dp))
                                        Text("Read the entire Bible in one year. Each day has a portion of chapters from Genesis through Revelation. Your progress is saved on this device and works offline.", color = palette.text, lineHeight = 23.sp)
                                        Spacer(Modifier.height(12.dp))
                                        LinearProgressIndicator(progress = { completedCount / 365f }, modifier = Modifier.fillMaxWidth(), color = palette.accent)
                                        Text("$completedCount of 365 days completed · ${((completedCount / 365f) * 100).toInt()}%", color = palette.text, modifier = Modifier.padding(top = 6.dp))
                                    }
                                    item {
                                        Card(colors = CardDefaults.cardColors(containerColor = palette.surface), shape = RoundedCornerShape(16.dp)) {
                                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                                Text("DAY $todayDay · TODAY'S READING", color = palette.accent, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.height(8.dp))
                                                Text(todayPlan.label, color = palette.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                                                Spacer(Modifier.height(12.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Checkbox(checked = todayDay in completedStudyDays, onCheckedChange = { checked ->
                                                        scope.launch { dataStore.edit { prefs ->
                                                            val updated = (prefs[completedStudyDaysKey] ?: emptySet()).toMutableSet()
                                                            if (checked) updated.add(todayDay) else updated.remove(todayDay)
                                                            prefs[completedStudyDaysKey] = updated
                                                        } }
                                                    }, colors = CheckboxDefaults.colors(checkedColor = palette.accent))
                                                    Text(if (todayDay in completedStudyDays) "Today's reading completed" else "Mark today's reading complete", color = palette.text)
                                                }
                                                Button(onClick = {
                                                    val first = todayPlan.firstChapter
                                                    selectedBookCode = first.first
                                                    selectedChapter = first.second
                                                    selectedTab = "Read"
                                                    query = ""
                                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) {
                                                    Text("Start today's reading", color = if (palette.dark) palette.background else Color.White)
                                                }
                                            }
                                        }
                                    }
                                    item { Text("365-day reading schedule", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                                    items(plan) { dayPlan ->
                                        val isDone = dayPlan.day in completedStudyDays
                                        Card(colors = CardDefaults.cardColors(containerColor = palette.surface), shape = RoundedCornerShape(12.dp)) {
                                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(checked = isDone, onCheckedChange = { checked ->
                                                    scope.launch { dataStore.edit { prefs ->
                                                        val updated = (prefs[completedStudyDaysKey] ?: emptySet()).toMutableSet()
                                                        if (checked) updated.add(dayPlan.day) else updated.remove(dayPlan.day)
                                                        prefs[completedStudyDaysKey] = updated
                                                    } }
                                                }, colors = CheckboxDefaults.colors(checkedColor = palette.accent))
                                                Column(Modifier.weight(1f)) {
                                                    Text("Day ${dayPlan.day}", color = palette.accent, fontWeight = FontWeight.Bold)
                                                    Text(dayPlan.label, color = palette.text)
                                                }
                                                if (isDone) Icon(Icons.Default.CheckCircle, contentDescription = "Completed", tint = palette.accent)
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == "Theme") {
                            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Text("Choose your theme", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = palette.accent)
                                    Spacer(Modifier.height(6.dp))
                                    Text("Select the colours that feel comfortable for Bible reading. Your choice is saved on this device and works offline.", color = palette.text, lineHeight = 23.sp)
                                    Spacer(Modifier.height(10.dp))
                                }
                                items(appPalettes, key = { it.id }) { option ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = option.surface),
                                        shape = RoundedCornerShape(14.dp),
                                        onClick = { scope.launch { dataStore.edit { it[themeKey] = option.id } } }
                                    ) {
                                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(option.label, color = option.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                                Spacer(Modifier.height(8.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    listOf(option.background, option.surface, option.accent, option.text).forEach { swatch ->
                                                        Box(Modifier.size(width = 28.dp, height = 20.dp).background(swatch, RoundedCornerShape(5.dp)))
                                                    }
                                                    Text("Aa", color = option.text, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            if (themeId == option.id) Icon(Icons.Default.CheckCircle, contentDescription = "Selected theme", tint = option.accent)
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == "About") {
                            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
                                item {
                                    Text("About ScrollVerse Bible", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = palette.accent)
                                    Spacer(Modifier.height(12.dp))
                                    Text("This app includes Bible text for offline reading in English and Telugu.", color = palette.text, lineHeight = 24.sp)
                                    Spacer(Modifier.height(18.dp))
                                    Text("English text", fontWeight = FontWeight.Bold, color = palette.accent)
                                    Text("World English Bible (WEB). Public domain. Source: ebible.org/engwebp/", color = palette.text, lineHeight = 22.sp)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Telugu text", fontWeight = FontWeight.Bold, color = palette.accent)
                                    Text("Biblica® Open Telugu Contemporary Version. Used under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0). Source: ebible.org/Scriptures/details.php?id=telotsa. The translation name and attribution are retained here. See the source page for full notices and license terms.", color = palette.text, lineHeight = 22.sp)
                                    Spacer(Modifier.height(14.dp))
                                    Text("Bible text is provided for reading. Some verse numbering can differ between translations.", color = palette.text.copy(alpha = 0.65f), lineHeight = 22.sp)
                                }
                            }
                        } else {
                            val currentBible = bible
                            if (currentBible == null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    if (loadError == null) CircularProgressIndicator(color = palette.accent)
                                    else Text("Could not load Bible: $loadError", color = palette.text)
                                }
                            } else {
                                val selectedBook = currentBible.books.firstOrNull { it.code == selectedBookCode } ?: currentBible.books.first()
                                val filtered = remember(currentBible, selectedBookCode, selectedChapter, query, selectedTab, saved, highlighted) {
                                    currentBible.verses.filter { verse ->
                                        val inSaved = verse.id in saved || verse.id in highlighted
                                        val matchesLocation = if (query.isNotBlank() || selectedTab == "Saved") {
                                            true
                                        } else {
                                            verse.bookCode == selectedBookCode && verse.chapter == selectedChapter
                                        }
                                        val matchesQuery = query.isBlank() ||
                                            verse.english.contains(query, ignoreCase = true) ||
                                            verse.telugu.contains(query, ignoreCase = true) ||
                                            verse.id.contains(query, ignoreCase = true) ||
                                            currentBible.books.firstOrNull { it.code == verse.bookCode }?.let {
                                                it.english.contains(query, true) || it.telugu.contains(query, true)
                                            } == true
                                        val hasSelectedLanguageText = when (language) {
                                            "English" -> verse.english.isNotBlank()
                                            "తెలుగు" -> verse.telugu.isNotBlank()
                                            else -> verse.english.isNotBlank() || verse.telugu.isNotBlank()
                                        }
                                        (selectedTab != "Saved" || inSaved) && matchesLocation && matchesQuery && hasSelectedLanguageText
                                    }
                                }
                                if (query.isNotBlank()) {
                                    Text("Search results: ${filtered.size}", color = palette.accent, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                                } else if (selectedTab == "Read") {
                                    Text(
                                        "${if (language == "తెలుగు") selectedBook.telugu else selectedBook.english} · Chapter $selectedChapter",
                                        color = palette.accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                                    )
                                }
                                LazyColumn(
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 24.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (filtered.isEmpty()) {
                                        item { Text("No verses found. Try another search or choose a different chapter.", color = palette.text.copy(alpha = 0.65f), modifier = Modifier.padding(16.dp)) }
                                    }
                                    items(filtered, key = { it.id }) { verse ->
                                        val book = currentBible.books.firstOrNull { it.code == verse.bookCode } ?: selectedBook
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = if (verse.id in highlighted) palette.highlighted else palette.surface),
                                            shape = RoundedCornerShape(14.dp)
                                        ) {
                                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                                Text(verse.reference(book, language), color = palette.accent, fontWeight = FontWeight.SemiBold)
                                                Spacer(Modifier.height(8.dp))
                                                if (language != "తెలుగు" && verse.english.isNotBlank()) {
                                                    Text(verse.english, fontSize = 17.sp, lineHeight = 25.sp, color = palette.text)
                                                }
                                                if (language != "English" && verse.telugu.isNotBlank()) {
                                                    if (language == "Both" && verse.english.isNotBlank()) Spacer(Modifier.height(9.dp))
                                                    Text(verse.telugu, fontSize = 18.sp, lineHeight = 29.sp, color = palette.text)
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = {
                                                        scope.launch { dataStore.edit { prefs ->
                                                            val current = (prefs[savedKey] ?: emptySet()).toMutableSet()
                                                            if (!current.add(verse.id)) current.remove(verse.id)
                                                            prefs[savedKey] = current
                                                        } }
                                                    }) {
                                                        Icon(if (verse.id in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                                            contentDescription = "Bookmark verse", tint = palette.accent)
                                                    }
                                                    IconButton(onClick = {
                                                        scope.launch { dataStore.edit { prefs ->
                                                            val current = (prefs[highlightedKey] ?: emptySet()).toMutableSet()
                                                            if (!current.add(verse.id)) current.remove(verse.id)
                                                            prefs[highlightedKey] = current
                                                        } }
                                                    }) {
                                                        Icon(Icons.Default.Highlight, contentDescription = "Highlight verse",
                                                            tint = if (verse.id in highlighted) palette.accent else palette.accent.copy(alpha = 0.65f))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BookPicker(
    modifier: Modifier = Modifier,
    books: List<BibleBook>,
    selected: BibleBook?,
    language: String,
    onSelect: (BibleBook) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.let { if (language == "తెలుగు") it.telugu else it.english } ?: "Book", maxLines = 1)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
            books.forEach { book ->
                DropdownMenuItem(
                    text = { Text(if (language == "తెలుగు") book.telugu else book.english) },
                    onClick = { onSelect(book); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun ChapterPicker(chapters: List<Int>, selectedChapter: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text("Ch. $selectedChapter") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
            chapters.forEach { chapter ->
                DropdownMenuItem(text = { Text(chapter.toString()) }, onClick = { onSelect(chapter); expanded = false })
            }
        }
    }
}
